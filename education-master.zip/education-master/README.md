# Education For All
Building a bridge between language and education .Resolving the real issues faced by rural people in education sector.

 ## What problem we are trying to solve ? <br/>
 Urban students are blessed with the resources internet today has to offer. But for rural area student, the connectivity is distant reality. Therefore a solution where providing the rural area students contents and resources for learning through internet is challenge in itself .A solution based solely on technology , needs infrastructure advancements before even implementing the actual solution.<br/>
 ![image](https://github.com/neeraj0403/IXI2020_KPN-creators/blob/master/WhatsApp%20Image%202020-02-04%20at%203.33.58%20PM.jpeg)
 <br/><br/>
Hence , deduce the solution that incorporates technology to the minimum and solve major problems in rural education , such as LACK OF RESOURCES and LANGUAGE BARRIER.


## Our Solution
AS PER PROBLEM STATEMENT , WE HAVE BUILT A SYSTEM THAT IS :
Rather than coming up with a platform , we incorporate our solution to the already available Ministry of Education initiative.

Ministry of Education started an initiative in which students pursuing higher education can watch supportive video lectures from professors of reputed universities through specially broadcasted channels.

We take use of this content and propose a solution where with the help of our application , the lectures broadcasted in the TV can be translated to the real time offline.

What all the user needs?
Just a 50 rupee a aux cable and smartphone.

![image](https://github.com/neeraj0403/IXI2020_KPN-creators/blob/master/WhatsApp%20Image%202020-02-04%20at%203.33.58%20PM%20(1).jpeg)

![image](https://github.com/neeraj0403/IXI2020_KPN-creators/blob/master/WhatsApp%20Image%202020-02-04%20at%203.34.12%20PM.jpeg)


### Tech Stack
 - Android Studio
 - TensorFlow
 - Phython
 - HTML
 - CSS



 
