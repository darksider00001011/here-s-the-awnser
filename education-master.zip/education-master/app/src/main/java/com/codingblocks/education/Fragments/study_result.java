package com.codingblocks.education.Fragments;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.codingblocks.education.R;
import com.github.mikephil.charting.charts.BarChart;

/**
 * A simple {@link Fragment} subclass.
 */
public class study_result extends Fragment {


    public study_result() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_study_result, container, false);
//        BarChart chart1 = (BarChart) view.findViewById(R.id.barchart1);
//        BarChart chart2=view.findViewById(R.id.barchart2);
//        BarChart chart3=view.findViewById(R.id.barchart3);
//        BarChart chart4=findViewById(R.id.barchart4);
//        BarChart chart5=findViewById(R.id.barchart5);
//        BarChart chart6=findViewById(R.id.barchart6);









        return  view;
    }

}
