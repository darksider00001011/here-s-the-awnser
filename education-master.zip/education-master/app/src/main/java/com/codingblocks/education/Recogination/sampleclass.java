package com.codingblocks.education.Recogination;

public class sampleclass {
}
